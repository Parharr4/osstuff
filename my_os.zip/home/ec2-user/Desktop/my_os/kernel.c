#include "./include/console.h"

void kernel_early(void) {
}

int main(void) 
{

	char* str1 = "Hello";
	char* str2 = "WORLD";
	char* str3 = "TODAY";
	char* str4 = "Next Line is Cool";
	print_string(str1);
        print_line(str2);
	print_line(str3);
	print_string(str4);
	
	shift();

	return 0;
}

#ifndef CONSOLE_H
#define CONSOLE_H

static const int VGA_HEIGHT = 25;
static const int VGA_WIDTH = 80;
static unsigned int t_row = 1;
static unsigned int t_col = 0;


void print_character(char data);
void print_string(char* data);
void print_line(char* data);
void shift();

#endif

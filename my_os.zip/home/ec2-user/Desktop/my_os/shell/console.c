#include "../include/console.h"

//Variables 
static char* const VGA_MEMORY = (char*) 0xb8000;

void print_character(char data)
{
	VGA_MEMORY[t_col] = data; // The ascii character
	VGA_MEMORY[t_col+1] = 0x07; // Color of the text
	t_col = t_col + 2;
}
void print_string(char* data)
{
	unsigned int curr_c = 0;
	while(data[curr_c] != '\0')
	{
		print_character(data[curr_c]);
		curr_c++;
	}	
}
void print_line(char* data)
{
	print_string(data);
	t_row ++;
	//This will always go to the start of the next line 
	t_col = (t_row -1)*(2*VGA_WIDTH);
}
void shift()
{
	for(int height = 0; height < VGA_HEIGHT; height++){
		for (int width = 0; width < VGA_WIDTH; width++){
			unsigned int initial = height * (VGA_WIDTH * 2) + width;
			unsigned int new     = (height + 1) * (VGA_WIDTH * 2) + width;
			VGA_MEMORY[initial]  = VGA_MEMORY[new];
		}
	}
}
